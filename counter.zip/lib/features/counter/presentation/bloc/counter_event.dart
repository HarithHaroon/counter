part of 'counter_bloc.dart';

@freezed
class CounterEvent with _$CounterEvent {
  const factory CounterEvent.changePage(int index) = _ChangePage;

  const factory CounterEvent.changeAppBarIndex(int index) = _ChangeAppBarIndex;

  const factory CounterEvent.increment({
    required int count1,
    required int count2,
    required int count3,
  }) = _Increment;
}
