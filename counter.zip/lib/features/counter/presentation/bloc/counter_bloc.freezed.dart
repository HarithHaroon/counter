// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'counter_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$CounterEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int index) changePage,
    required TResult Function(int index) changeAppBarIndex,
    required TResult Function(int count1, int count2, int count3) increment,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function(int index)? changePage,
    TResult Function(int index)? changeAppBarIndex,
    TResult Function(int count1, int count2, int count3)? increment,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int index)? changePage,
    TResult Function(int index)? changeAppBarIndex,
    TResult Function(int count1, int count2, int count3)? increment,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangePage value) changePage,
    required TResult Function(_ChangeAppBarIndex value) changeAppBarIndex,
    required TResult Function(_Increment value) increment,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(_ChangePage value)? changePage,
    TResult Function(_ChangeAppBarIndex value)? changeAppBarIndex,
    TResult Function(_Increment value)? increment,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangePage value)? changePage,
    TResult Function(_ChangeAppBarIndex value)? changeAppBarIndex,
    TResult Function(_Increment value)? increment,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CounterEventCopyWith<$Res> {
  factory $CounterEventCopyWith(
          CounterEvent value, $Res Function(CounterEvent) then) =
      _$CounterEventCopyWithImpl<$Res>;
}

/// @nodoc
class _$CounterEventCopyWithImpl<$Res> implements $CounterEventCopyWith<$Res> {
  _$CounterEventCopyWithImpl(this._value, this._then);

  final CounterEvent _value;
  // ignore: unused_field
  final $Res Function(CounterEvent) _then;
}

/// @nodoc
abstract class _$$_ChangePageCopyWith<$Res> {
  factory _$$_ChangePageCopyWith(
          _$_ChangePage value, $Res Function(_$_ChangePage) then) =
      __$$_ChangePageCopyWithImpl<$Res>;
  $Res call({int index});
}

/// @nodoc
class __$$_ChangePageCopyWithImpl<$Res> extends _$CounterEventCopyWithImpl<$Res>
    implements _$$_ChangePageCopyWith<$Res> {
  __$$_ChangePageCopyWithImpl(
      _$_ChangePage _value, $Res Function(_$_ChangePage) _then)
      : super(_value, (v) => _then(v as _$_ChangePage));

  @override
  _$_ChangePage get _value => super._value as _$_ChangePage;

  @override
  $Res call({
    Object? index = freezed,
  }) {
    return _then(_$_ChangePage(
      index == freezed
          ? _value.index
          : index // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$_ChangePage implements _ChangePage {
  const _$_ChangePage(this.index);

  @override
  final int index;

  @override
  String toString() {
    return 'CounterEvent.changePage(index: $index)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ChangePage &&
            const DeepCollectionEquality().equals(other.index, index));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(index));

  @JsonKey(ignore: true)
  @override
  _$$_ChangePageCopyWith<_$_ChangePage> get copyWith =>
      __$$_ChangePageCopyWithImpl<_$_ChangePage>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int index) changePage,
    required TResult Function(int index) changeAppBarIndex,
    required TResult Function(int count1, int count2, int count3) increment,
  }) {
    return changePage(index);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function(int index)? changePage,
    TResult Function(int index)? changeAppBarIndex,
    TResult Function(int count1, int count2, int count3)? increment,
  }) {
    return changePage?.call(index);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int index)? changePage,
    TResult Function(int index)? changeAppBarIndex,
    TResult Function(int count1, int count2, int count3)? increment,
    required TResult orElse(),
  }) {
    if (changePage != null) {
      return changePage(index);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangePage value) changePage,
    required TResult Function(_ChangeAppBarIndex value) changeAppBarIndex,
    required TResult Function(_Increment value) increment,
  }) {
    return changePage(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(_ChangePage value)? changePage,
    TResult Function(_ChangeAppBarIndex value)? changeAppBarIndex,
    TResult Function(_Increment value)? increment,
  }) {
    return changePage?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangePage value)? changePage,
    TResult Function(_ChangeAppBarIndex value)? changeAppBarIndex,
    TResult Function(_Increment value)? increment,
    required TResult orElse(),
  }) {
    if (changePage != null) {
      return changePage(this);
    }
    return orElse();
  }
}

abstract class _ChangePage implements CounterEvent {
  const factory _ChangePage(final int index) = _$_ChangePage;

  int get index;
  @JsonKey(ignore: true)
  _$$_ChangePageCopyWith<_$_ChangePage> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_ChangeAppBarIndexCopyWith<$Res> {
  factory _$$_ChangeAppBarIndexCopyWith(_$_ChangeAppBarIndex value,
          $Res Function(_$_ChangeAppBarIndex) then) =
      __$$_ChangeAppBarIndexCopyWithImpl<$Res>;
  $Res call({int index});
}

/// @nodoc
class __$$_ChangeAppBarIndexCopyWithImpl<$Res>
    extends _$CounterEventCopyWithImpl<$Res>
    implements _$$_ChangeAppBarIndexCopyWith<$Res> {
  __$$_ChangeAppBarIndexCopyWithImpl(
      _$_ChangeAppBarIndex _value, $Res Function(_$_ChangeAppBarIndex) _then)
      : super(_value, (v) => _then(v as _$_ChangeAppBarIndex));

  @override
  _$_ChangeAppBarIndex get _value => super._value as _$_ChangeAppBarIndex;

  @override
  $Res call({
    Object? index = freezed,
  }) {
    return _then(_$_ChangeAppBarIndex(
      index == freezed
          ? _value.index
          : index // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$_ChangeAppBarIndex implements _ChangeAppBarIndex {
  const _$_ChangeAppBarIndex(this.index);

  @override
  final int index;

  @override
  String toString() {
    return 'CounterEvent.changeAppBarIndex(index: $index)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ChangeAppBarIndex &&
            const DeepCollectionEquality().equals(other.index, index));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(index));

  @JsonKey(ignore: true)
  @override
  _$$_ChangeAppBarIndexCopyWith<_$_ChangeAppBarIndex> get copyWith =>
      __$$_ChangeAppBarIndexCopyWithImpl<_$_ChangeAppBarIndex>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int index) changePage,
    required TResult Function(int index) changeAppBarIndex,
    required TResult Function(int count1, int count2, int count3) increment,
  }) {
    return changeAppBarIndex(index);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function(int index)? changePage,
    TResult Function(int index)? changeAppBarIndex,
    TResult Function(int count1, int count2, int count3)? increment,
  }) {
    return changeAppBarIndex?.call(index);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int index)? changePage,
    TResult Function(int index)? changeAppBarIndex,
    TResult Function(int count1, int count2, int count3)? increment,
    required TResult orElse(),
  }) {
    if (changeAppBarIndex != null) {
      return changeAppBarIndex(index);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangePage value) changePage,
    required TResult Function(_ChangeAppBarIndex value) changeAppBarIndex,
    required TResult Function(_Increment value) increment,
  }) {
    return changeAppBarIndex(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(_ChangePage value)? changePage,
    TResult Function(_ChangeAppBarIndex value)? changeAppBarIndex,
    TResult Function(_Increment value)? increment,
  }) {
    return changeAppBarIndex?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangePage value)? changePage,
    TResult Function(_ChangeAppBarIndex value)? changeAppBarIndex,
    TResult Function(_Increment value)? increment,
    required TResult orElse(),
  }) {
    if (changeAppBarIndex != null) {
      return changeAppBarIndex(this);
    }
    return orElse();
  }
}

abstract class _ChangeAppBarIndex implements CounterEvent {
  const factory _ChangeAppBarIndex(final int index) = _$_ChangeAppBarIndex;

  int get index;
  @JsonKey(ignore: true)
  _$$_ChangeAppBarIndexCopyWith<_$_ChangeAppBarIndex> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_IncrementCopyWith<$Res> {
  factory _$$_IncrementCopyWith(
          _$_Increment value, $Res Function(_$_Increment) then) =
      __$$_IncrementCopyWithImpl<$Res>;
  $Res call({int count1, int count2, int count3});
}

/// @nodoc
class __$$_IncrementCopyWithImpl<$Res> extends _$CounterEventCopyWithImpl<$Res>
    implements _$$_IncrementCopyWith<$Res> {
  __$$_IncrementCopyWithImpl(
      _$_Increment _value, $Res Function(_$_Increment) _then)
      : super(_value, (v) => _then(v as _$_Increment));

  @override
  _$_Increment get _value => super._value as _$_Increment;

  @override
  $Res call({
    Object? count1 = freezed,
    Object? count2 = freezed,
    Object? count3 = freezed,
  }) {
    return _then(_$_Increment(
      count1: count1 == freezed
          ? _value.count1
          : count1 // ignore: cast_nullable_to_non_nullable
              as int,
      count2: count2 == freezed
          ? _value.count2
          : count2 // ignore: cast_nullable_to_non_nullable
              as int,
      count3: count3 == freezed
          ? _value.count3
          : count3 // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$_Increment implements _Increment {
  const _$_Increment(
      {required this.count1, required this.count2, required this.count3});

  @override
  final int count1;
  @override
  final int count2;
  @override
  final int count3;

  @override
  String toString() {
    return 'CounterEvent.increment(count1: $count1, count2: $count2, count3: $count3)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Increment &&
            const DeepCollectionEquality().equals(other.count1, count1) &&
            const DeepCollectionEquality().equals(other.count2, count2) &&
            const DeepCollectionEquality().equals(other.count3, count3));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(count1),
      const DeepCollectionEquality().hash(count2),
      const DeepCollectionEquality().hash(count3));

  @JsonKey(ignore: true)
  @override
  _$$_IncrementCopyWith<_$_Increment> get copyWith =>
      __$$_IncrementCopyWithImpl<_$_Increment>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int index) changePage,
    required TResult Function(int index) changeAppBarIndex,
    required TResult Function(int count1, int count2, int count3) increment,
  }) {
    return increment(count1, count2, count3);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function(int index)? changePage,
    TResult Function(int index)? changeAppBarIndex,
    TResult Function(int count1, int count2, int count3)? increment,
  }) {
    return increment?.call(count1, count2, count3);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int index)? changePage,
    TResult Function(int index)? changeAppBarIndex,
    TResult Function(int count1, int count2, int count3)? increment,
    required TResult orElse(),
  }) {
    if (increment != null) {
      return increment(count1, count2, count3);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangePage value) changePage,
    required TResult Function(_ChangeAppBarIndex value) changeAppBarIndex,
    required TResult Function(_Increment value) increment,
  }) {
    return increment(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(_ChangePage value)? changePage,
    TResult Function(_ChangeAppBarIndex value)? changeAppBarIndex,
    TResult Function(_Increment value)? increment,
  }) {
    return increment?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangePage value)? changePage,
    TResult Function(_ChangeAppBarIndex value)? changeAppBarIndex,
    TResult Function(_Increment value)? increment,
    required TResult orElse(),
  }) {
    if (increment != null) {
      return increment(this);
    }
    return orElse();
  }
}

abstract class _Increment implements CounterEvent {
  const factory _Increment(
      {required final int count1,
      required final int count2,
      required final int count3}) = _$_Increment;

  int get count1;
  int get count2;
  int get count3;
  @JsonKey(ignore: true)
  _$$_IncrementCopyWith<_$_Increment> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$CounterState {
  int get count1 => throw _privateConstructorUsedError;
  int get count2 => throw _privateConstructorUsedError;
  int get count3 => throw _privateConstructorUsedError;
  int get pageIndex => throw _privateConstructorUsedError;
  int get appBarIndex => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $CounterStateCopyWith<CounterState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CounterStateCopyWith<$Res> {
  factory $CounterStateCopyWith(
          CounterState value, $Res Function(CounterState) then) =
      _$CounterStateCopyWithImpl<$Res>;
  $Res call(
      {int count1, int count2, int count3, int pageIndex, int appBarIndex});
}

/// @nodoc
class _$CounterStateCopyWithImpl<$Res> implements $CounterStateCopyWith<$Res> {
  _$CounterStateCopyWithImpl(this._value, this._then);

  final CounterState _value;
  // ignore: unused_field
  final $Res Function(CounterState) _then;

  @override
  $Res call({
    Object? count1 = freezed,
    Object? count2 = freezed,
    Object? count3 = freezed,
    Object? pageIndex = freezed,
    Object? appBarIndex = freezed,
  }) {
    return _then(_value.copyWith(
      count1: count1 == freezed
          ? _value.count1
          : count1 // ignore: cast_nullable_to_non_nullable
              as int,
      count2: count2 == freezed
          ? _value.count2
          : count2 // ignore: cast_nullable_to_non_nullable
              as int,
      count3: count3 == freezed
          ? _value.count3
          : count3 // ignore: cast_nullable_to_non_nullable
              as int,
      pageIndex: pageIndex == freezed
          ? _value.pageIndex
          : pageIndex // ignore: cast_nullable_to_non_nullable
              as int,
      appBarIndex: appBarIndex == freezed
          ? _value.appBarIndex
          : appBarIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
abstract class _$$_CounterStateCopyWith<$Res>
    implements $CounterStateCopyWith<$Res> {
  factory _$$_CounterStateCopyWith(
          _$_CounterState value, $Res Function(_$_CounterState) then) =
      __$$_CounterStateCopyWithImpl<$Res>;
  @override
  $Res call(
      {int count1, int count2, int count3, int pageIndex, int appBarIndex});
}

/// @nodoc
class __$$_CounterStateCopyWithImpl<$Res>
    extends _$CounterStateCopyWithImpl<$Res>
    implements _$$_CounterStateCopyWith<$Res> {
  __$$_CounterStateCopyWithImpl(
      _$_CounterState _value, $Res Function(_$_CounterState) _then)
      : super(_value, (v) => _then(v as _$_CounterState));

  @override
  _$_CounterState get _value => super._value as _$_CounterState;

  @override
  $Res call({
    Object? count1 = freezed,
    Object? count2 = freezed,
    Object? count3 = freezed,
    Object? pageIndex = freezed,
    Object? appBarIndex = freezed,
  }) {
    return _then(_$_CounterState(
      count1: count1 == freezed
          ? _value.count1
          : count1 // ignore: cast_nullable_to_non_nullable
              as int,
      count2: count2 == freezed
          ? _value.count2
          : count2 // ignore: cast_nullable_to_non_nullable
              as int,
      count3: count3 == freezed
          ? _value.count3
          : count3 // ignore: cast_nullable_to_non_nullable
              as int,
      pageIndex: pageIndex == freezed
          ? _value.pageIndex
          : pageIndex // ignore: cast_nullable_to_non_nullable
              as int,
      appBarIndex: appBarIndex == freezed
          ? _value.appBarIndex
          : appBarIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$_CounterState implements _CounterState {
  const _$_CounterState(
      {required this.count1,
      required this.count2,
      required this.count3,
      required this.pageIndex,
      required this.appBarIndex});

  @override
  final int count1;
  @override
  final int count2;
  @override
  final int count3;
  @override
  final int pageIndex;
  @override
  final int appBarIndex;

  @override
  String toString() {
    return 'CounterState(count1: $count1, count2: $count2, count3: $count3, pageIndex: $pageIndex, appBarIndex: $appBarIndex)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CounterState &&
            const DeepCollectionEquality().equals(other.count1, count1) &&
            const DeepCollectionEquality().equals(other.count2, count2) &&
            const DeepCollectionEquality().equals(other.count3, count3) &&
            const DeepCollectionEquality().equals(other.pageIndex, pageIndex) &&
            const DeepCollectionEquality()
                .equals(other.appBarIndex, appBarIndex));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(count1),
      const DeepCollectionEquality().hash(count2),
      const DeepCollectionEquality().hash(count3),
      const DeepCollectionEquality().hash(pageIndex),
      const DeepCollectionEquality().hash(appBarIndex));

  @JsonKey(ignore: true)
  @override
  _$$_CounterStateCopyWith<_$_CounterState> get copyWith =>
      __$$_CounterStateCopyWithImpl<_$_CounterState>(this, _$identity);
}

abstract class _CounterState implements CounterState {
  const factory _CounterState(
      {required final int count1,
      required final int count2,
      required final int count3,
      required final int pageIndex,
      required final int appBarIndex}) = _$_CounterState;

  @override
  int get count1;
  @override
  int get count2;
  @override
  int get count3;
  @override
  int get pageIndex;
  @override
  int get appBarIndex;
  @override
  @JsonKey(ignore: true)
  _$$_CounterStateCopyWith<_$_CounterState> get copyWith =>
      throw _privateConstructorUsedError;
}
