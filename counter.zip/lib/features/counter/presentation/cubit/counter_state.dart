part of 'counter_cubit.dart';

@freezed
class CounterState with _$CounterState {
  const factory CounterState.initial() = _Initial;
  const factory CounterState.increment() = _Increment;
  const factory CounterState.changePage(int index) = _ChangePage;
  const factory CounterState.changeAppBarIndex(int index) = _ChangeAppBarIndex;
  const factory CounterState.countValues({
    required int counter1,
    required int counter2,
    required int counter3,
  }) = _CountValues;
}
