import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'counter_state.dart';
part 'counter_cubit.freezed.dart';

class CounterCubit extends Cubit<CounterState> {
  CounterCubit() : super(const CounterState.initial());

  int selectedIndex = 0;
  int currentPage = 0;

  changeSelectedIndex(int newIndex) {
    selectedIndex = newIndex;
    emit(CounterState.changePage(newIndex));
  }

  changeAppBarIndex(int newIndex) {
    currentPage = newIndex;
    emit(CounterState.changeAppBarIndex(newIndex));
  }

  incrementCounter() {
    // emit(CounterState.countValues(counter1: counter1, counter2: counter2, counter3: counter3))
  }
}
