import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'features/counter/presentation/cubit/counter_cubit.dart';
import 'features/counter/presentation/screens/first_counter_screen.dart';
import 'features/counter/presentation/screens/second_counter_screen.dart';
import 'features/counter/presentation/screens/third_counter_screen.dart';

class App extends StatelessWidget {
  App({super.key});

  final List<Widget> _screens = [
    FirstCounterScreen(),
    SecondCounterScreen(),
    ThirdCounterScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final counterCubit = context.read<CounterCubit>();

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: BlocBuilder<CounterCubit, CounterState>(
        builder: (context, state) {
          return Scaffold(
            appBar: AppBar(
              title: Text('Counter ${counterCubit.currentPage}'),
            ),
            body: _screens.elementAt(counterCubit.selectedIndex),
            bottomNavigationBar: BottomNavigationBar(
              currentIndex: counterCubit.selectedIndex,
              onTap: (tabIndex) {
                counterCubit.changeSelectedIndex(tabIndex);
                counterCubit.changeAppBarIndex(tabIndex);
              },
              items: const <BottomNavigationBarItem>[
                BottomNavigationBarItem(
                  icon: Icon(Icons.punch_clock),
                  label: 'Counter 1',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.punch_clock),
                  label: 'Counter 2',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.punch_clock),
                  label: 'Counter 3',
                ),
              ],
            ),
            floatingActionButton: FloatingActionButton(
              onPressed: () {
                //
              },
              tooltip: 'Increment current counter',
              child: const Icon(Icons.add),
            ),
          );
        },
      ),
    );
  }
}
